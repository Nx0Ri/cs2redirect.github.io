Все скриншоты и сама папка с оптимизацией сделана NxORi
Оригинал взят у Denis-G | Windows 10 Latency Optimization (https://github.com/denis-g/windows10-latency-optimization)

Что изменилось от оригинала в папке - Все программы на месте, а все файлы реестра уже собраны в один
Вопросы или нужна помощь? Пишите в дискорд: nxori_
